<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:31.5648px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:27.5445px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:27.6834px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:24.9315px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:24.1162px;}
	.st11{opacity:0.99;fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;enable-background:new    ;}
	.st12{font-size:17.2558px;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st16{font-size:25.2506px;}
	.st17{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st18{fill:#9b9b9b;}
	.st19{font-size:20.8097px;}
	.st20{font-size:20.9848px;}
	.st21{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st22{font-size:20.857px;}
	.st23{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st24{font-size:21.1759px;}
	.st25{font-size:21.3881px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>