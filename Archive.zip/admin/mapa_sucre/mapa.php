<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;}
	.st1{font-family:'ArialMT';}
	.st2{font-size:22.274px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;}
	.st4{fill:#9b9b9b;stroke:#FFFFFF;}
	.st5{font-size:20.1423px;}
	.st6{fill:#9b9b9b;stroke:#FFFFFF;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;}
	.st8{font-size:18.6717px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;}
	.st10{font-size:21.3464px;}
	.st11{font-size:18.8424px;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;}
	.st14{font-size:17.3527px;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;}
	.st16{fill:#9b9b9b;stroke:#FFFFFF;}
	.st17{font-size:17.667px;}
	.st18{font-size:19.1287px;}
	.st19{font-size:21px;}
	.st20{font-size:18.318px;}
	.st21{font-size:14.4821px;}
	.st22{font-size:21.0978px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>