<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:25.7457px;}
	.st3{fill:#9b9b9b;}
	.st4{font-size:26.8925px;}
	.st5{fill:#9b9b9b;}
	.st6{font-size:24.7846px;}
	.st7{fill:#9b9b9b;}
	.st8{font-size:20.0934px;}
	.st9{fill:#9b9b9b;}
	.st10{fill:#9b9b9b;}
	.st11{font-size:13.7967px;}
	.st12{fill:#9b9b9b;}
	.st13{font-size:15.6533px;}
	.st14{fill:#9b9b9b;}
	.st15{font-size:16.2412px;}
	.st16{fill:#9b9b9b;}
	.st17{fill:#9b9b9b;}
	.st18{fill:#9b9b9b;}
	.st19{font-size:27.3355px;}
	.st20{fill:#9b9b9b;}
	.st21{fill:#9b9b9b;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>