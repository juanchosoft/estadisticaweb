<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;}
	.st1{font-family:'ArialMT';}
	.st2{font-size:17.4921px;}
	.st3{fill:#9b9b9b;}
	.st4{fill:#9b9b9b;}
	.st5{fill:#9b9b9b;}
	.st6{fill:#9b9b9b;}
	.st7{fill:#9b9b9b;}
	.st8{fill:#9b9b9b;}
	.st9{fill:#9b9b9b;}
	.st10{fill:#9b9b9b;}
	.st11{fill:#9b9b9b;}
	.st12{font-size:21.131px;}
	.st13{fill:#9b9b9b;}
	.st14{fill:#9b9b9b;}
	.st15{font-size:14.7421px;}
	.st16{font-size:16.3713px;}
	.st17{font-size:21.3769px;}
	.st18{font-size:19.1052px;}
	.st19{font-size:16.0098px;}
	.st20{font-size:15.5434px;}
	.st21{font-size:16.0257px;}
	.st22{font-size:15.5804px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>