<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:29.8577px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st5{font-size:34.291px;}
	.st6{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:26.7972px;}
	.st9{fill:#9b9b9b;}
	.st10{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st13{font-size:23.7896px;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st16{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st17{font-size:25.0637px;}
	.st18{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>