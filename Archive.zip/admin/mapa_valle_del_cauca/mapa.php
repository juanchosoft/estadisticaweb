<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:20px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;}
	.st8{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{opacity:0.99;fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;enable-background:new    ;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st13{fill:#9b9b9b;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st16{font-size:22.0004px;}
	.st17{font-size:24.2003px;}
	.st18{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st19{font-size:18.1311px;}
	.st20{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st21{font-size:16.7397px;}
	.st22{font-size:25.3241px;}
	.st23{font-size:19.0431px;}
	.st24{font-size:28.1129px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>