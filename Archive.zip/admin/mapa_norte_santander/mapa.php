<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:17.5293px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;}
	.st4{font-size:17.5826px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;}
	.st6{font-size:16.9568px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;}
	.st8{fill:#9b9b9b;stroke:#FFFFFF;}
	.st9{font-size:21.2462px;}
	.st10{fill:#9b9b9b;stroke:#FFFFFF;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;}
	.st14{font-size:20.0306px;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;}
	.st16{font-size:21.0687px;}
	.st17{fill:#9b9b9b;stroke:#FFFFFF;}
	.st18{fill:#9b9b9b;stroke:#FFFFFF;}
	.st19{font-size:14.6318px;}
	.st20{font-size:13.8665px;}
	.st21{opacity:0.99;fill:#9b9b9b;stroke:#FFFFFF;enable-background:new    ;}
	.st22{font-size:15.1507px;}
	.st23{font-size:14.7909px;}
	.st24{font-size:15.3186px;}
	.st25{font-size:13.265px;}
	.st26{enable-background:new    ;}
	.st27{font-size:12.6838px;}
	.st28{font-size:13.0683px;}
	.st29{font-size:14.6761px;}
	.st30{font-size:12.9178px;}
	.st31{font-size:13.1684px;}
	.st32{font-size:16.0527px;}
	.st33{font-size:15.6902px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>