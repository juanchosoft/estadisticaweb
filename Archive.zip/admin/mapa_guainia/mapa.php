<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:20.6625px;}
	.st3{fill:#9b9b9b;}
	.st4{font-size:23.3554px;}
	.st5{fill:#9b9b9b;}
	.st6{font-size:27.7907px;}
	.st7{fill:#9b9b9b;}
	.st8{font-size:30.404px;}
	.st9{fill:#9b9b9b;}
	.st10{font-size:24.8635px;}
	.st11{fill:#9b9b9b;}
	.st12{font-size:26.6385px;}
	.st13{fill:#9b9b9b;}
	.st14{font-size:30.0949px;}
	.st15{fill:#9b9b9b;}
	.st16{font-size:25.7126px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>