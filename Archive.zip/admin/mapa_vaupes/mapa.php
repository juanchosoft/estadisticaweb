<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:28.4076px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st4{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st6{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>