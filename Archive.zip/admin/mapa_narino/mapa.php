<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:13.4797px;}
	.st3{fill:#9b9b9b;}
	.st4{fill:#9b9b9b;}
	.st5{fill:#9b9b9b;}
	.st6{fill:#9b9b9b;}
	.st7{fill:#9b9b9b;}
	.st8{fill:#9b9b9b;}
	.st9{enable-background:new    ;}
	.st10{font-size:22.7058px;}
	.st11{fill:#9b9b9b;}
	.st12{fill:#9b9b9b;}
	.st13{font-size:17.079px;}
	.st14{fill:#9b9b9b;}
	.st15{font-size:18.5659px;}
	.st16{font-size:20.4636px;}
	.st17{fill:#9b9b9b;}
	.st18{font-size:17.971px;}
	.st19{fill:#9b9b9b;}
	.st20{fill:#9b9b9b;}
	.st21{fill:#9b9b9b;}
	.st22{fill:#9b9b9b;}
	.st23{opacity:0.99;fill:#9b9b9b;enable-background:new    ;}
	.st24{font-size:15.4802px;}
	.st25{fill:#9b9b9b;}
	.st26{font-size:15.4122px;}
	.st27{font-size:17.5276px;}
	.st28{fill:#9b9b9b;}
	.st29{font-size:9.6136px;}
	.st30{font-size:12.9207px;}
	.st31{font-size:7.5658px;}
	.st32{fill:#9b9b9b;}
	.st33{font-size:11.5414px;}
	.st34{font-size:10.3525px;}
	.st35{fill:#9b9b9b;}
	.st36{font-size:11.1328px;}
	.st37{font-size:12.0997px;}
	.st38{font-size:11.2996px;}
	.st39{fill:#9b9b9b;}
	.st40{font-size:12.0301px;}
	.st41{font-size:9.676px;}
	.st42{fill:#9b9b9b;}
	.st43{font-size:10.5356px;}
	.st44{fill:#9b9b9b;}
	.st45{font-size:11.0817px;}
	.st46{fill:#9b9b9b;}
	.st47{font-size:9.3256px;}
	.st48{font-size:9.7597px;}
	.st49{fill:#9b9b9b;}
	.st50{font-size:10.8752px;}
	.st51{font-size:17.9599px;}
	.st52{font-size:14.9125px;}
	.st53{fill:#9b9b9b;}
	.st54{font-size:7.7274px;}
	.st55{font-size:7.5016px;}
	.st56{fill:#9b9b9b;}
	.st57{font-size:9.6195px;}
	.st58{font-size:10.206px;}
	.st59{font-size:9.3294px;}
	.st60{font-size:9.0959px;}
	.st61{font-size:9.201px;}
	.st62{fill:#9b9b9b;}
	.st63{font-size:10.1466px;}
	.st64{font-size:10.6588px;}
	.st65{font-size:8.822px;}
	.st66{font-size:10.7339px;}
	.st67{font-size:11.7199px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>