<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;}
	.st1{font-family:'ArialMT';}
	.st2{font-size:11.2984px;}
	.st3{fill:#9b9b9b;}
	.st4{font-size:13.0862px;}
	.st5{fill:#9b9b9b;}
	.st6{font-size:13.6892px;}
	.st7{fill:#9b9b9b;}
	.st8{fill:#9b9b9b;}
	.st9{font-size:13.325px;}
	.st10{fill:#9b9b9b;}
	.st11{fill:#9b9b9b;}
	.st12{font-size:12.4271px;}
	.st13{fill:#9b9b9b;}
	.st14{fill:#9b9b9b;}
	.st15{fill:#9b9b9b;}
	.st16{font-size:12.598px;}
	.st17{font-size:9.543px;}
	.st18{font-size:8.7354px;}
	.st19{font-size:10.6847px;}
	.st20{fill:#9b9b9b;}
	.st21{font-size:9.6717px;}
	.st22{opacity:0.99;fill:#9b9b9b;enable-background:new    ;}
	.st23{font-size:9px;}
	.st24{font-size:9.6622px;}
	.st25{font-size:9.6909px;}
	.st26{enable-background:new    ;}
	.st27{font-size:11px;}
	.st28{font-size:10.4857px;}
	.st29{font-size:9.623px;}
	.st30{font-size:9.7322px;}
	.st31{font-size:8.3059px;}
	.st32{font-size:6.5458px;}
	.st33{font-size:7px;}
	.st34{font-size:6.8116px;}
	.st35{font-size:8.9766px;}
	.st36{font-size:10.46px;}
	.st37{font-size:9.0548px;}
	.st38{font-size:7.7137px;}
	.st39{font-size:8px;}
	.st40{font-size:8.3723px;}
	.st41{font-size:9.3341px;}
	.st42{font-size:9.4126px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>