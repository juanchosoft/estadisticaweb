<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:15.285px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st5{font-size:19.6833px;}
	.st6{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:15.5667px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:0.6168;stroke-miterlimit:10;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:0.6168;stroke-miterlimit:10;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:0.6168;stroke-miterlimit:10;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:0.6168;stroke-miterlimit:10;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:0.6168;stroke-miterlimit:10;}
	.st15{font-size:11.9686px;}
	.st16{font-size:12.4342px;}
	.st17{font-size:9.9349px;}
	.st18{enable-background:new    ;}
	.st19{font-size:13px;}
	.st20{font-size:12px;}
	.st21{font-size:14px;}
	.st22{font-size:13.709px;}
</style>
<?php include './generic_municipios_svg_render.php'; ?>