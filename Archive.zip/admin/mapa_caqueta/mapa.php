<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:24.5154px;}
	.st3{fill:#9b9b9b;}
	.st4{font-size:16.6026px;}
	.st5{fill:#9b9b9b;}
	.st6{font-size:17.4539px;}
	.st7{fill:#9b9b9b;}
	.st8{font-size:13.5594px;}
	.st9{fill:#9b9b9b;}
	.st10{font-size:12.7342px;}
	.st11{fill:#9b9b9b;}
	.st12{font-size:12.4099px;}
	.st13{fill:#9b9b9b;}
	.st14{fill:#9b9b9b;}
	.st15{font-size:13.2757px;}
	.st16{fill:#9b9b9b;}
	.st17{fill:#9b9b9b;}
	.st18{fill:#9b9b9b;}
	.st19{fill:#9b9b9b;}
	.st20{fill:#9b9b9b;}
	.st21{fill:#9b9b9b;}
	.st22{font-size:12.3744px;}
	.st23{fill:#9b9b9b;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>