<!-- Navbar Unificado Profesional -->
<div class="container-fluid p-0">
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow d-flex align-items-center" id="mainNavbar">

        <!-- LOGO IZQUIERDA -->
        <a href="dash_responder.php" class="navbar-brand ms-3 d-flex align-items-center">
            <img src="assets/img/admin/estadistica3.png"
                 alt="Logo"
                 style="height:40px; width:auto;">
        </a>

        <!-- Toggler móvil -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>

        <!-- Contenido menú -->
        <div class="collapse navbar-collapse" id="navbarCollapse">

            <!-- DESKTOP -->
            <div class="navbar-nav ms-auto d-none d-lg-flex">

                <!-- NUEVO TEXTO -->
                <a href="dash_responder.php" class="nav-item nav-link">¡Formularios Pendientes!</a>

                <!-- NUEVO TEXTO -->
                <a href="visualizar.php" class="nav-item nav-link">Consultar Estadísticas Nacionales</a>

                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center"
                       href="#" role="button" data-bs-toggle="dropdown">

                        <i class="fas fa-user-circle me-2 text-primary fa-2x"></i>

                        <span class="fw-bold">
                            <?php
                                $nombreCompleto = $_SESSION['session_user']['nombre_completo']
                                                  ?? $_SESSION['session_user']['usuario']
                                                  ?? 'Usuario';
                                $p = explode(' ', $nombreCompleto);
                                echo htmlspecialchars($p[0] . " " . ($p[1] ?? ""));
                            ?>
                        </span>

                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                        <li>
                            <a class="dropdown-item"
                               href="#"
                               onclick="PERFIL.loadProfile(<?php echo $_SESSION['session_user']['id']; ?>); return false;">
                                <i class="fas fa-user me-2"></i>Mi Perfil
                            </a>
                        </li>

                        <li><hr class="dropdown-divider"></li>

                        <li>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                            </a>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- MOBILE MENU -->
            <div class="navbar-nav ms-auto d-lg-none w-100 mt-3">

                <!-- Caja de usuario -->
                <div class="user-info-mobile mb-3 p-3 bg-light rounded shadow-sm">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-user-circle me-3 text-primary fa-2x"></i>
                        <div>
                            <span class="fw-bold">
                                <?php
                                    $nombreCompleto = $_SESSION['session_user']['nombre_completo']
                                                      ?? $_SESSION['session_user']['usuario']
                                                      ?? 'Usuario';
                                    $p = explode(' ', $nombreCompleto);
                                    echo htmlspecialchars($p[0] . " " . ($p[1] ?? ""));
                                ?>
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Items móvil con textos NUEVOS -->
                <a href="dash_responder.php" class="nav-item nav-link d-flex align-items-center mb-2">
                    <i class="fas fa-chart-bar me-3"></i>¡Formularios Pendientes!
                </a>

                <a href="visualizar.php" class="nav-item nav-link d-flex align-items-center mb-2">
                    <i class="fas fa-chart-bar me-3"></i>Consultar Estadísticas Nacionales
                </a>

                <hr class="my-3">

                <a href="#" class="nav-item nav-link d-flex align-items-center mb-2"
                   onclick="PERFIL.loadProfile(<?php echo $_SESSION['session_user']['id']; ?>); return false;">
                    <i class="fas fa-user me-3"></i>Mi Perfil
                </a>

                <a href="logout.php" class="nav-item nav-link text-danger d-flex align-items-center">
                    <i class="fas fa-sign-out-alt me-3"></i>Cerrar Sesión
                </a>

            </div>

        </div>

    </nav>
</div>

<!-- Corrección de altura -->
<script>
document.addEventListener("scroll", () => {
    const nav = document.getElementById("mainNavbar");
    nav.classList.toggle("scrolled", window.scrollY > 10);
});

function aplicarMargenNavbar() {
    const nav = document.getElementById("mainNavbar");
    if (!nav) return;
    document.body.style.marginTop = nav.offsetHeight + "px";
}
document.addEventListener("DOMContentLoaded", aplicarMargenNavbar);
window.addEventListener("resize", aplicarMargenNavbar);
</script>
