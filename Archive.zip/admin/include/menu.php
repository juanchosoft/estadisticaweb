<div class="container-fluid p-0">
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow d-flex align-items-center" id="mainNavbar">

        <!-- LOGO IZQUIERDA -->
        <a href="index.php" class="navbar-brand ms-3 d-flex align-items-center">
            <img src="assets/img/admin/estadistica3.png" 
                 alt="Logo" 
                 style="height:40px; width:auto;">
        </a>

        <!-- Botón móvil: Ingresar -->
        <button type="button" class="btn btn-outline-primary d-lg-none ms-auto me-2" 
                data-bs-toggle="modal" data-bs-target="#loginModal">
            <i class="fa fa-user me-2"></i>Ingresar
        </button>

        <!-- Botón menú móvil -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>

        <!-- Menú -->
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto py-0">
                <a href="index.php" class="nav-item nav-link">Inicio</a>
                <a href="nosotros.php" class="nav-item nav-link">Quienes somos</a>
                <a href="servicios.php" class="nav-item nav-link">Servicios</a>
                <a href="contacto.php" class="nav-item nav-link">Contacto</a>
            </div>
        </div>
<!-- Botón escritorio -->
<button type="button" class="btn btn-light border ms-3 d-none d-lg-block"
        data-bs-toggle="modal" data-bs-target="#loginModal">
    <i class="fa fa-user me-2"></i>Ingresar
</button>


    </nav>
</div>

<!-- Funciones que reparan el menu  -->
<script>
document.addEventListener("scroll", function() {
    const nav = document.getElementById("mainNavbar");
    if (window.scrollY > 10) {
        nav.classList.add("scrolled");
    } else {
        nav.classList.remove("scrolled");
    }
});

function aplicarMargenNavbar() {
    const nav = document.getElementById("mainNavbar");
    if (!nav) return;

    const altura = nav.offsetHeight;
    document.body.style.marginTop = altura + "px";
}

document.addEventListener("DOMContentLoaded", aplicarMargenNavbar);
// Ajusta si cambia el tamaño de ventana
window.addEventListener("resize", aplicarMargenNavbar);
</script>
