<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:28.9448px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:25.8772px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:28.2566px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:24px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:24.4442px;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{font-size:18.8188px;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st16{font-size:16.4425px;}
	.st17{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st18{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st19{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st20{font-size:16.253px;}
	.st21{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st22{fill:#9b9b9b;}
	.st23{font-size:15.0108px;}
	.st24{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st25{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st26{font-size:12.4633px;}
	.st27{font-size:14.729px;}
	.st28{font-size:17.2466px;}
	.st29{font-size:16.4088px;}
	.st30{opacity:0.99;fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;enable-background:new    ;}
	.st31{font-size:26.1206px;}
	.st32{fill:#9b9b9b;}
	.st33{font-size:16.4259px;}
	.st34{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st35{font-size:13.6079px;}
	.st36{font-size:12.0776px;}
	.st37{font-size:26.1619px;}
	.st38{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st39{font-size:25.4627px;}
	.st40{font-size:15.1321px;}
	.st41{fill:#9b9b9b;}
	.st42{font-size:15.8912px;}
	.st43{font-size:16.7179px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>