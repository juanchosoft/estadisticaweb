<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:21.0534px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:21px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:16.8271px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:21.6988px;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st14{font-size:19.7715px;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;}
	.st16{font-size:13.9128px;}
	.st17{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st18{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st19{font-size:15.7043px;}
	.st20{font-size:14.3854px;}
	.st21{font-size:14.3119px;}
	.st22{font-size:14.3928px;}
	.st23{font-size:14.5021px;}
	.st24{font-size:14.1623px;}
	.st25{font-size:10.9552px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>