<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:26.0369px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:18.9589px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:20.4083px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st9{font-size:22.5058px;}
	.st10{font-size:25.9067px;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{font-size:22.5573px;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st14{font-size:17.3835px;}
	.st15{font-size:27.0677px;}
	.st16{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st17{font-size:20.6328px;}
	.st18{font-size:21.7312px;}
	.st19{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st20{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st21{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st22{font-size:15.1853px;}
	.st23{font-size:15.0198px;}
	.st24{font-size:16.6238px;}
	.st25{opacity:0.99;fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;enable-background:new    ;}
	.st26{font-size:16.5931px;}
	.st27{font-size:26.1276px;}
	.st28{font-size:16.2969px;}
	.st29{font-size:17.0266px;}
	.st30{font-size:15.9477px;}
	.st31{font-size:15.7368px;}
</style>
<?php include './generic_municipios_svg_render.php'; ?>