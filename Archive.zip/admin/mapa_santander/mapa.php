<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
.st0{fill:#FF8F33;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:11.9488px;}
	.st3{fill:#57A3FF;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:13.6629px;}
	.st5{fill:#D57BFF;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:13.1384px;}
	.st7{fill:#F1FF66;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{fill:#FFD400;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st9{fill:#89F7F1;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:10.302px;}
	.st11{fill:#2FB524;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{fill:#2DEA9D;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st13{fill:#FCAF70;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st14{fill:#ACDD50;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st15{fill:#344CF7;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st16{fill:#EBCEF2;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st17{font-size:10.4888px;}
	.st18{fill:#F95D77;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st19{font-size:8.7099px;}
	.st20{font-size:13.0442px;}
	.st21{font-size:11px;}
	.st22{font-size:14.7048px;}
	.st23{font-size:13.6539px;}
	.st24{font-size:17.3519px;}
	.st25{font-size:13.7798px;}
	.st26{font-size:13px;}
	.st27{font-size:10.4072px;}
	.st28{font-size:10px;}
	.st29{fill:#E8F2AD;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st30{font-size:12px;}
	.st31{font-size:10.5514px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>