<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{opacity:0.99;fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;enable-background:new    ;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:22.2686px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:30.27px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:23.5969px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:25.5289px;}
	.st11{font-size:26.7005px;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st13{font-size:26.5069px;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st15{font-size:19.7395px;}
	.st16{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st17{font-size:25.6679px;}
	.st18{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st19{font-size:24.3582px;}
	.st20{font-size:28.8107px;}
	.st21{font-size:26.3341px;}
	.st22{font-size:23.9815px;}
	.st23{font-size:26.5669px;}
	.st24{font-size:17.3261px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>