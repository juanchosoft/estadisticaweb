// Botón atrás
function goBack() {
    if (document.referrer && document.referrer !== window.location.href) {
        history.back();
    } else {
        window.location.href = 'dashboard.php';
    }
}

function redirectToEncuesta() {
    window.location.href = 'encuesta.php';
}

function redirectToSondeo() {
    window.location.href = 'sondeo.php';
}

function redirectToEstudio() {
    window.location.href = 'grilla.php';
}

document.addEventListener('DOMContentLoaded', function () {
    const spinner = document.getElementById('spinner');
    if (spinner) spinner.style.display = 'none';

    const COLOR_NEUTRO = "rgb(192, 192, 192)";

    setTimeout(function () {

        const paths = document.querySelectorAll('svg path');

        paths.forEach(path => {
            path.style.cursor = 'pointer';

            path.addEventListener('click', function () {

                // Obtener color real
                const color = window.getComputedStyle(this).fill.trim().toLowerCase();

                // Evitar clic en departamentos grises
                if (color === COLOR_NEUTRO) {
                    return;
                }

                const modal = new bootstrap.Modal(document.getElementById('alertModal'));
                modal.show();
            });
        });

        console.log("Mapa listo con validación de color neutro");

    }, 300);
});
