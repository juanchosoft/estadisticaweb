const ColoresCandidatos = {
    1: "#1f77b4",
    2: "#ff7f0e",
    3: "#2ca02c",
    4: "#d62728"
};

$(document).ready(function () {

    let grafico = null;
    let graficoGeneral = null;
function pintarMapaSegunGanadores() {

    const departamentos = [];

    $("#mapaContainer svg g").each(function () {
        const dep = $(this).attr("id");
        const codigo = $(this).find("path").data("codigo");
        if (codigo) departamentos.push(codigo);
    });

    $.ajax({
        url: "admin/Ajax/rqst.php",
        type: "POST",
        dataType: "json",
        data: {
            op: "mapa_colores_departamentos",
            departamentos: departamentos
        },
        success: function (res) {

            if (!res.success) return;

            const info = res.data;

            $("#mapaContainer svg g").each(function () {

                const path = $(this).find("path");
                const codigo = path.data("codigo");
                if (!codigo) return;

                const ganador = info[codigo];

                if (!ganador) return;

                if (ganador.empate) {

                    // EMPATE → rayado
                    path.css("fill", "url(#rayas)");

                } else {

                    // GANADOR → color asignado
                    const color = ColoresCandidatos[ganador.ganador] || "#999";
                    path.css("fill", color);
                }
            });
        }
    });

}


function cargarGraficoGeneral() {

    $.ajax({
        url: "admin/Ajax/rqst.php",
        type: "POST",
        dataType: "json",
        data: { op: "sondeo_presidencial_general" },
        success: function (res) {

            if (!res.success || !res.votos) return;

            const canvas = document.getElementById('graficoGeneral');
            if (!canvas) return;

            if (graficoGeneral) graficoGeneral.destroy();


        function dividirEnTresLineas(nombre) {

            const palabras = nombre.split(" ");

            if (palabras.length === 1) {
                return [palabras[0]]; 
            }

            if (palabras.length === 2) {
                return [palabras[0], palabras[1]];
            }

            let linea1 = palabras[0];
            let linea2 = palabras[1] + (palabras[2] ? " " + palabras[2] : "");
            let linea3 = palabras.slice(3).join(" ");

            const lineas = [linea1, linea2];

            if (linea3.trim() !== "") lineas.push(linea3);

            return lineas;
        }


const labels = res.votos.map(v => dividirEnTresLineas(v.nombre_completo));
            const data = res.votos.map(v => Number(v.total || 0));
            const imagenes = res.votos.map(v => v.foto_url);

            const imgs = imagenes.map(src => {
                const img = new Image();
                img.src = src;
                return img;
            });

            const colores = [
                "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
                "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
                "#bcbd22", "#17becf"
            ];
            const coloresAsignados = data.map((v, i) => colores[i % colores.length]);

            // plugin que dibuja FOTO + LABEL junto al eje Y
            const fotoLabelPlugin = {
                id: 'fotoLabelPlugin',
                afterDraw(chart) {

                    const ctx = chart.ctx;
                    const yAxis = chart.scales.y;

                    ctx.textBaseline = "middle";
                    ctx.textAlign = "left";
                    ctx.font = "12px sans-serif";

                    chart.data.labels.forEach((label, i) => {

                        const y = yAxis.getPixelForTick(i);

                        const img = imgs[i];
                        const imgY = y - 15;

                        ctx.drawImage(img, 5, imgY, 30, 30);

                        label.forEach((line, lineIndex) => {
                            ctx.fillStyle = "#000";
                            ctx.fillText(line, 40, y + (lineIndex * 12) - 6);
                        });
                    });
                }
            };

            graficoGeneral = new Chart(canvas, {
                type: 'bar',
                plugins: [fotoLabelPlugin],
                data: {
                    labels: labels,
                    datasets: [{
                        label: "",
                        data: data,
                        backgroundColor: coloresAsignados
                    }]
                },
                options: {
                    indexAxis: "y",
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: {
                        x: { beginAtZero: true },
                        y: {
                            ticks: { display: false }
                        }
                    },
                    layout: {
                        padding: { left: 80 }
                    }
                }
            });
        }
    });
}

    cargarGraficoGeneral();

    const MapaSondeo = {

        departamentoActual: "",
        municipioActual: "",

        init() {
            this.hacerMapaClickeable();
            this.eventos();
        },

        hacerMapaClickeable() {
            setTimeout(() => {
                $('#mapaContainer svg path').each(function () {
                    $(this).addClass('mapaClick');
                    $(this).css('cursor', 'pointer');
                });
            }, 100);
        },

        eventos() {
            $('#closeCard').on('click', function (e) {
                e.stopPropagation();
                $('#resultadosCard').addClass('d-none');
            });

            $(document).on('click', function (e) {
                if (!$(e.target).closest('#resultadosCard').length &&
                    !$(e.target).closest('.mapaClick').length) {
                    $('#resultadosCard').addClass('d-none');
                }
            });

            $('#resultadosCard').on('click', function (e) {
                e.stopPropagation();
            });

            $(document).on('click', '.mapaClick', (e) => {
                this.manejarClickMapa(e);
            });
        },

        manejarClickMapa(e) {
            e.preventDefault();
            e.stopPropagation();

            const path = $(e.target);

            const nombreReal = path.data("nombre");     
            const codigoDane = path.data("codigo");       

            this.departamentoActual = codigoDane;
            this.municipioActual = "";

            this.posicionarCard(e.pageX, e.pageY);

            // Mostrar nombre en badge
            $('#badgeElectoral').text(nombreReal.toUpperCase());

            this.obtenerSondeo(codigoDane);
        },


        posicionarCard(x, y) {
            const cardWidth = 360;
            const cardHeight = 500;
            const ww = $(window).width();
            const wh = $(window).height();

            let finalX = x + 15;
            let finalY = y - 15;

            if (finalX + cardWidth > ww) finalX = x - cardWidth - 15;
            if (finalY + cardHeight > wh) finalY = wh - cardHeight - 15;
            if (finalY < 0) finalY = 15;
            if (finalX < 0) finalX = 15;

            $('#resultadosCard')
                .removeClass('d-none')
                .css({ top: finalY + "px", left: finalX + "px" });
        },

        obtenerSondeo(departamento) {

            $('#resultadosContent').html(`
                <div class="text-center p-4">
                    <div class="spinner-border text-primary"></div>
                    <p class="mt-2 text-muted">Cargando sondeo...</p>
                </div>
            `);

            $.ajax({
                url: "admin/Ajax/rqst.php",
                type: "POST",
                dataType: "json",
                data: {
                    op: "sondeo_presidencial_mapa",
                    departamento_click: departamento
                },
                success: (res) => {
                    if (!res.success || !res.votos || res.votos.length === 0) {
                        this.mostrarSondeoVacio();
                        this.actualizarGrafico([]);
                        return;
                    }

                    this.mostrarSondeo(res.votos);
                    this.actualizarGrafico(res.votos);
                },
                error: () => {
                    this.mostrarSondeoVacio();
                    this.actualizarGrafico([]);
                }
            });
        },

        mostrarSondeo(votos) {

            let total = votos.reduce((t, v) => t + Number(v.total || 0), 0);
            votos.sort((a, b) => Number(b.total || 0) - Number(a.total || 0));

            let html = "";

            votos.forEach((v) => {
                const votosNum = Number(v.total || 0);
                const porcentaje = total > 0
                    ? ((votosNum / total) * 100).toFixed(1)
                    : 0;

                html += `
                    <div class="p-3 border-bottom d-flex gap-3">
                        <img src="${v.foto_url}" 
                            style="width:50px;height:50px;object-fit:cover;border-radius:50%;">
                        <div class="flex-grow-1">
                            <strong>${v.nombre_completo}</strong>
                            <div class="d-flex justify-content-between text-muted">
                                <span>${votosNum} votos</span>
                                <span>${porcentaje}%</span>
                            </div>
                            <div class="progress mt-2" style="height:5px;">
                                <div class="progress-bar bg-primary" style="width:${porcentaje}%"></div>
                            </div>
                        </div>
                    </div>
                `;
            });

            $('#resultadosContent').html(html);
        },

        actualizarGrafico(votos) {

            const ctx = document.getElementById('graficoVotos');

            if (!ctx) return;

            if (grafico) grafico.destroy();

            const labels = votos.map(v => v.nombre_completo);
            const data = votos.map(v => Number(v.total || 0));

            grafico = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Votos',
                        data: data,
                        backgroundColor: 'rgba(30, 144, 255, 0.7)'
                    }]
                },
                options: {
                    responsive: true,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true } }
                }
            });
        },

        mostrarSondeoVacio() {
            $('#resultadosContent').html(`
                <div class="p-4 text-center text-muted">
                    Sin datos disponibles
                </div>
            `);
        }
    };

    MapaSondeo.init();

});
