<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'ArialMT';}
	.st2{font-size:25.4684px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:20.2496px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:21.7255px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:21.167px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:21.51px;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{font-size:20.5051px;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st14{font-size:20.3717px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>