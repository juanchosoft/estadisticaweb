<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:16.6739px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:18.1453px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:14.0895px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:15.3973px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:18.542px;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st13{font-size:13.9556px;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st15{font-size:13.6386px;}
	.st16{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st17{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st18{font-size:18.0655px;}
	.st19{font-size:14.0966px;}
	.st20{font-size:16.6402px;}
	.st21{font-size:14.5279px;}
	.st22{font-size:19.4519px;}
	.st23{font-size:17.275px;}
	.st24{font-size:18px;}
	.st25{font-size:14.1071px;}
	.st26{font-size:17.0191px;}
	.st27{font-size:17.4254px;}
	.st28{font-size:17.8955px;}
	.st29{font-size:18.8104px;}
	.st30{font-size:18.2598px;}
	.st31{font-size:17.6367px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>