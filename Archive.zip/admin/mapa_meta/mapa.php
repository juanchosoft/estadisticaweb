<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:23.8962px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:21.8882px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:17.7302px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{font-size:18.8587px;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{font-size:17.1172px;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{font-size:15.2234px;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st14{font-size:21.5941px;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st16{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st17{font-size:14.4294px;}
	.st18{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st19{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st20{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st21{font-size:17.6793px;}
	.st22{fill:#9b9b9b;stroke:#FFFFFF;}
	.st23{font-size:12.3489px;}
	.st24{font-size:14.1186px;}
	.st25{font-size:14.3597px;}
	.st26{font-size:18.6428px;}
	.st27{font-size:22.7752px;}
	.st28{font-size:14.1476px;}
	.st29{font-size:12.8886px;}
	.st30{font-size:12.4247px;}
	.st31{font-size:11.9829px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>