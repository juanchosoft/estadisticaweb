<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:13.1166px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st4{font-size:15.9314px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st6{font-size:13.6395px;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st8{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st10{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st12{fill:#9b9b9b;stroke:#FFFFFF;stroke-miterlimit:10;}
	.st13{font-size:11.9536px;}
	.st14{font-size:14.356px;}
	.st15{font-size:15.4014px;}
	.st16{font-size:14.6177px;}
	.st17{font-size:12.1649px;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>