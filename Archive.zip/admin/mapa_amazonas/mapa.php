<?php include './generic_clases_mapa.php'; ?>

<!-- css styles de cada mapa, departamento -->
<style type="text/css">
	.st0{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st1{font-family:'MyriadPro-Regular';}
	.st2{font-size:28.5815px;}
	.st3{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st4{font-size:22.5776px;}
	.st5{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st6{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st7{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st8{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st9{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st10{font-size:24.614px;}
	.st11{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st12{font-size:28px;}
	.st13{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st14{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
	.st15{fill:#9b9b9b;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;}
</style>

<?php include './generic_municipios_svg_render.php'; ?>