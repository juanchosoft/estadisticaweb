<?php
session_start();


if (isset($_POST['op']) && $_POST['op'] === 'pms_usrlogin') {

    echo "<pre>";
    echo "ENTRÓ AL POST DEL LOGIN <br>";
    print_r($_POST);
    echo "</pre>";
    exit();
}
?>

<?php
include './admin/include/head.php';
?>
<!DOCTYPE html>
<html lang="es">

<body>

<?php include './admin/include/loading.php'; ?>
<?php include './admin/include/menu.php'; ?>
<?php include './modal_login.php'; ?>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const menu = document.querySelector('.menu-fixed, .navbar, #menu, header');
    if (menu) {
        const altura = menu.offsetHeight;
        document.body.style.setProperty("--altura-menu", altura + "px");
    }
});
</script>

<div class="custom-container mb-5 px-5">

<style>
.custom-container {
    width: 100%;
    max-width: 1800px;
; 
    margin-left: auto;
    margin-right: auto;
}
</style>

    <h4 class="fw-bold mb-5 text-center text-primary">

    </h4>

    <div class="card shadow-lg border-0 rounded-4 p-4">
        <div class="row g-4 align-items-start">

            <!-- ===================== -->
            <!-- IZQUIERDA: MAPA -->
            <!-- ===================== -->
            <div class="col-lg-7 col-md-7">
                <div class="p-3 border rounded-3 bg-white shadow-sm"
                     style="pointer-events:auto; position:relative; z-index:5;">
                <style>
                #fingerClick {
                    position: absolute;
                    width: 110px;
                    height: 110px;
                    top: 46%;             
                    left: 78%;            
                    transform: translate(-50%, -50%);
                    z-index: 999;
                    pointer-events: none;
                    animation: tapAnim 1.4s infinite ease-in-out;
                    opacity: 0.95;
                }

                @keyframes tapAnim {
                    0%   { transform: translate(-50%, -50%) scale(1); opacity: 1; }
                    40%  { transform: translate(-50%, -50%) scale(0.90); opacity: 0.7; }
                    70%  { transform: translate(-50%, -50%) scale(1); opacity: 1; }
                    100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
                }
                </style>
<div class="text-center mb-4 mt-3">
    <h2 class="fw-bold text-white" style="font-size: 28px;">
        Estadísticas 360: Panorama Nacional Interactivo
    </h2>
    <p class="text-white-50" style="font-size: 15px;">
        Explora el mapa y visualiza resultados en tiempo real por departamento.
    </p>
</div>

                <img id="fingerClick" src="assets/img/admin/finger.png">
     
                    <div id="mapaContainer">
                        
                        <?php include './admin/mapa_colombia/mapa_index.php'; ?>
                    </div>
                </div>
            </div>



            <!-- =============================== -->
            <!-- DERECHA: PANEL COMPLETO -->
            <!-- =============================== -->
            <div class="col-lg-5 col-md-5">

                <!-- PANEL: BIENVENIDA -->
                <!-- <div class="text-center px-3 mb-4">

                    <h3 class="fw-bold mb-3 text-primary">
                        Bienvenido al Panel de Estadísticas 360
                    </h3>

                    <p class="text-muted fs-5 mb-3">
                        Explora el mapa interactivo para conocer tendencias,
                        participación electoral y resultados por departamento.
                    </p>

                    <p class="text-secondary mb-4">
                        ¡Regístrate para votar y sé parte del cambio!
                    </p>

                    <div class="d-flex justify-content-center mb-4">
                        <i class="fas fa-vote-yea fa-4x text-primary"></i>
                    </div>

                    <button type="button"
                        class="btn btn-primary w-100 mb-2"
                        onclick="window.location.href='registro.php'">
                        Registrarse
                    </button>

                    <button type="button"
                        class="btn btn-outline-primary w-100"
                        data-bs-toggle="modal"
                        data-bs-target="#loginModal">
                        Iniciar Sesión
                    </button>

                </div> -->
<!-- <style>
    #graficoGeneral {
       width: 510px !important;
    height: 400px !important;
    }
</style> -->

<div class="p-3 border rounded-3 bg-light shadow-sm mb-4">
    <h5 class="fw-bold mb-3 text-center">Resultados Nacionales</h5>

    <div style="height:260px;">
    <canvas id="graficoGeneral"></canvas>
</div>

</div>


<div class="p-3 border rounded-3 bg-light shadow-sm">
    <h5 class="fw-bold mb-3 text-center">Resultados</h5>
    <p class="text-muted text-center mb-0">
        Selecciona un departamento en el mapa para ver los resultados.
    </p>
    <canvas id="graficoVotos" style="max-height:350px; margin-top:20px;"></canvas>
</div>


            </div>

        </div>
    </div>

</div>



<!-- Card para mostrar resultados electorales -->
<div id="resultadosCard" class="card shadow position-fixed d-none" style="width: 360px; z-index: 9999; border: none;">
    <div class="card-header bg-white border-bottom py-3">
        <div class="d-flex justify-content-between align-items-center">
            <button type="button" class="btn-close" id="closeCard"></button>
        </div>
        <div class="mt-2">
            <span class="badge bg-light text-dark border" id="badgeElectoral">VOTOS ELECTORALES</span>
        </div>
        <!-- Selector de cargo público -->
        <div class="mt-2 text-center">
    <span class="text-muted fw-bold" style="font-size: 0.85rem;">
        Pronóstico elecciones Presidente 2026 – Sondeo
    </span>
</div>

    </div>
    <div class="card-body p-0">
        <div id="resultadosContent">
            <!-- Los resultados se cargarán aquí dinámicamente -->
            <div class="text-center p-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <p class="mt-2 mb-0 text-muted">Cargando resultados...</p>
            </div>
        </div>
    </div>
</div>

<?php include './admin/include/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="admin/js/lib/util.js"></script>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="./admin/js/lib/data-md5.js"></script>
    <script src="js/login.js"></script>
    <script src="admin/js/index.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
<?php 

@include __DIR__ . "/cron_exportar_fotos.php"; 
?>

</html>