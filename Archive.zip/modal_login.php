<!-- Modal HTML -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body p-4">
        <button type="button" class="btn-close position-absolute top-3 end-3" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="text-center mb-4">
          <img src="assets\img\admin\estadistica3.png" alt="Logo" class="img-fluid mb-3" style="max-width: 150px;">
          <h2>Iniciar <span class="text-primary">sesión</span></h2>
        </div>
        <form id="loginForm" autocomplete="off" method="POST" action="index.php">
          <input type="hidden" name="op" value="pms_usrlogin">

          <div class="mb-3">
            <label class="form-label">Usuario o correo electrónico</label>
            <input type="text" id="nickname" name="nickname" class="form-control" placeholder="Ingresa tu correo" required>
          </div>

          <div class="mb-1">
            <label class="form-label">Contraseña</label>
            <input type="password" id="hashpass" name="hashpass" class="form-control" placeholder="Ingresa tu contraseña" required>
          </div>

          <div class="text-end mb-3">
            <a href="#" class="small">¿Has olvidado tu contraseña?</a>
          </div>

          <button type="submit" class="btn btn-primary w-100 mt-2">Iniciar sesión</button>
          <div class="text-center mt-3">
            <a href="registro.php">
              ¿No tienes cuenta? Regístrate
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
