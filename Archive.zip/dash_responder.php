<?php
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['session_user']) || !isset($_SESSION['session_user']['id'])) {
    header('Location: index.php');
    exit();
}
require './admin/include/generic_classes.php';

// Obtener nombre del usuario para el mensaje
$nombreUsuario = $_SESSION['session_user']['nombre_completo'] ?? $_SESSION['session_user']['usuario'] ?? 'Usuario';
$partes = explode(' ', $nombreUsuario);
$primerNombre = $partes[0] ?? 'Usuario';

?>
<!DOCTYPE html>
<html lang="en">

<?php include './admin/include/head2.php'; ?>
<?php include './admin/include/menusecond.php'; ?>  

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->
    
    <!-- Modal de Alerta Pendientes -->
    <div class="modal fade alert-modal" id="alertModal" tabindex="-1" aria-labelledby="alertModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-white" id="alertModalLabel">
                        <i class="fas fa-info-circle me-2"></i>¡Formularios Pendientes!
                    </h5>
                    <button type="button" class="btn-close-custom" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <h4 class="mb-2">HOLA, <?php echo htmlspecialchars($primerNombre); ?></h4>
                    <p class="text-muted mb-3">Tienes formularios pendientes por responder</p>
                    
                    <p class="text-primary fw-bold mb-4">¡Cuál quieres responder!</p>
                    
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-option d-flex align-items-center justify-content-center" onclick="redirectToEncuesta()">
                            <i class="fas fa-clipboard-list me-3 fa-lg"></i>
                            <div class="text-start">
                                <strong>Responder Encuesta</strong>
                                <small class="d-block text-white-50">Completar formulario de encuesta</small>
                            </div>
                        </button>
                        
                        <button type="button" class="btn btn-option d-flex align-items-center justify-content-center" onclick="redirectToSondeo()">
                            <i class="fas fa-poll me-3 fa-lg"></i>
                            <div class="text-start">
                                <strong>Responder Sondeo</strong>
                                <small class="d-block text-white-50">Completar formulario de sondeo</small>
                            </div>
                        </button>
                        
                        <button type="button" class="btn btn-option d-flex align-items-center justify-content-center" onclick="redirectToEstudio()">
                            <i class="fas fa-chart-bar me-3 fa-lg"></i>
                            <div class="text-start">
                                <strong>Responder Estudio</strong>
                                <small class="d-block text-white-50">Completar formulario de estudio</small>
                            </div>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
  
<div class="container-fluid p-0">
    <div class="container-fluid d-flex justify-content-center align-items-center"
         style="min-height: calc(100vh - 90px); padding: 20px;">

        <div class="col-lg-10 col-md-11 col-sm-12">
            <div class="card shadow-lg p-4 border-0" style="border-radius: 16px;">

                <div class="row g-4 align-items-start">

                    <div class="col-lg-7 col-md-7">
                        <div class="p-3 border rounded-3 bg-white shadow-sm"
                             style="pointer-events:auto; position:relative; z-index:5;">
                            <?php include './admin/mapa_colombia/mapa.php'; ?>
                        </div>
                    </div>

                    <div class="col-lg-5 col-md-5">
                    <div class="text-center px-3 mb-4">

                        <h3 class="fw-bold mb-2 text-primary">
                            <i class="fas fa-chart-bar me-2"></i>
                            ¿Tienes formularios pendientes?
                        </h3>

                        <p class="text-muted fs-5 mb-3">
                            Elige tu departamento para responderlos. Podrás completar encuestas, sondeos y estudios.
                        </p>

                        <div class="d-flex justify-content-center mb-2">
                            <i class="fas fa-hand-pointer fa-3x text-primary"></i>
                        </div>

                    </div>

                    <div class="p-3 border rounded-3 bg-light shadow-sm" style="max-width:260px; margin:0 auto;">

                        <h5 class="fw-bold mb-3 text-center">
                            <i class="fas fa-info-circle me-2 text-primary"></i>
                            Formularios pendientes
                        </h5>

                        <p class="text-muted text-center mb-1">
                            Actualmente tienes:
                        </p>

                        <p class="text-center mb-1">
                            <b id="pendientes_sondeos">0</b> sondeos pendientes
                        </p>
                        <p class="text-center mb-1">
                            <b id="pendientes_estudios">0</b> estudios pendientes
                        </p>
                        <p class="text-center mb-1">
                            <b id="pendientes_encuestas">0</b> encuestas pendientes
                        </p>

                    </div>

                </div>
                </div>

            </div>
        </div>

    </div>
</div>


    
    <?php include './admin/include/perfil.php';?>
    <?php include './admin/include/footer.php';?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript" src="./admin/js/lib/data-md5.js"></script>
    <script src="admin/js/perfil.js"></script>
    <script src="admin/js/responder.js"></script>
<!-- <script>
window.MAPA_COLOR_NEUTRO = "<?= Util::getColorNeutroMapa(); ?>";
</script> -->
    <script src="js/main.js"></script>

</body>
</html>