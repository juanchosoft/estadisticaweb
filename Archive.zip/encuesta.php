<?php
require_once './admin/include/generic_classes.php';
include './admin/classes/Pregunta.php';
include './admin/classes/FichaTecnicaEncuesta.php';
include './admin/classes/RespuestaCuestionario.php';
include './admin/include/generic_info_configuracion.php';

// Obtener ID de ficha técnica desde URL
$fichaTecnicaId = isset($_GET['f']) ? intval($_GET['f']) : 0;

// Obtener ID del votante logueado
$votanteId = SessionData::getUserId();

// Si no viene ID, mostrar selector de encuestas
$todasFichasTecnicas = [];
$encuestasPendientes = [];
$encuestasContestadas = [];
$mostrarSelector = false;

if ($fichaTecnicaId === 0) {
    $mostrarSelector = true;
    $todasFichasTecnicasResult = FichaTecnicaEncuesta::getAll([]);
    if ($todasFichasTecnicasResult['output']['valid']) {
        $todasFichasTecnicas = $todasFichasTecnicasResult['output']['response'];

        // Separar entre contestadas y pendientes
        foreach ($todasFichasTecnicas as $ficha) {
            $verificacion = RespuestaCuestionario::verificarSiYaContesto([
                'ficha_tecnica_id' => $ficha['id'],
                'votante_id' => $votanteId
            ]);

            $contestada = $verificacion['output']['contestada'] ?? false;

            if ($contestada) {
                $encuestasContestadas[] = $ficha;
            } else {
                $encuestasPendientes[] = $ficha;
            }
        }
    }
}

// Variables del cuestionario
$fichaTecnica = null;
$preguntas = [];
$encuestaYaContestada = false;

// Si viene ID, verificar primero si ya fue contestada
if ($fichaTecnicaId > 0) {
    // Verificar si ya contestó esta encuesta
    $verificacion = RespuestaCuestionario::verificarSiYaContesto([
        'ficha_tecnica_id' => $fichaTecnicaId,
        'votante_id' => $votanteId
    ]);

    $encuestaYaContestada = $verificacion['output']['contestada'] ?? false;

    if ($encuestaYaContestada) {
        // Redirigir al selector con mensaje
        header('Location: encuesta.php?ya_contestada=1');
        exit;
    }

    // Si NO ha contestado, cargar la ficha técnica y preguntas
    $fichaTecnicaResult = FichaTecnicaEncuesta::getAll(['id' => $fichaTecnicaId]);
    if ($fichaTecnicaResult['output']['valid'] && !empty($fichaTecnicaResult['output']['response'])) {
        $fichaTecnica = $fichaTecnicaResult['output']['response'][0];

        // Obtener preguntas de la ficha técnica
        $preguntasResult = Pregunta::getAll(['tbl_ficha_tecnica_encuesta_id' => $fichaTecnicaId]);
        if ($preguntasResult['output']['valid']) {
            $preguntas = $preguntasResult['output']['response'];
        }
    } else {
        $mostrarSelector = true;
        $todasFichasTecnicasResult = FichaTecnicaEncuesta::getAll([]);
        if ($todasFichasTecnicasResult['output']['valid']) {
            $todasFichasTecnicas = $todasFichasTecnicasResult['output']['response'];

            // Separar entre contestadas y pendientes
            foreach ($todasFichasTecnicas as $ficha) {
                $verificacion = RespuestaCuestionario::verificarSiYaContesto([
                    'ficha_tecnica_id' => $ficha['id'],
                    'votante_id' => $votanteId
                ]);

                $contestada = $verificacion['output']['contestada'] ?? false;

                if ($contestada) {
                    $encuestasContestadas[] = $ficha;
                } else {
                    $encuestasPendientes[] = $ficha;
                }
            }
        }
    }
}

// Información del proyecto
$configuracionAplicacion = Util::getInformacionConfiguracion();
$logo = !empty($configuracionAplicacion[0]['logo']) ? $configuracionAplicacion[0]['logo'] : '';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title><?= $mostrarSelector ? 'Seleccionar Encuesta' : 'Cuestionario - ' . htmlspecialchars($fichaTecnica['tema'] ?? 'Encuesta') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fuentes y estilos -->
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600&family=Roboto&display=swap" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
</head>

<body>
<?php include './admin/include/menusecond.php'; ?>

<!-- CONTENIDO -->
<div class="container py-5" id="cuestionario_container" data-ficha-tecnica-id="<?= $fichaTecnicaId ?>">

    <?php if ($mostrarSelector): ?>
        <div class="text-center mb-5">
            <h2 class="mb-3">Encuestas</h2>
            <p class="text-muted">Selecciona la encuesta que deseas responder.</p>
        </div>

        <?php if (isset($_GET['ya_contestada'])): ?>
            <div class="alert alert-warning alert-dismissible fade show mx-auto" style="max-width: 800px;" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Ya contestaste esta encuesta.</strong> No puedes volver a responderla.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="d-flex flex-column align-items-center">
            <?php if (count($encuestasPendientes) > 0): ?>
                <h4 class="text-start w-100 mb-3" style="max-width: 800px;">
                    <i class="fas fa-clipboard-user me-2"></i>Encuestas Pendientes
                </h4>
                <?php foreach ($encuestasPendientes as $ficha): ?>
                    <div class="card shadow-sm mb-4 p-4" style="max-width: 800px; width: 100%; border-color: #0b1a89;">
                        <div class="d-flex justify-content-between align-items-start">
                            <h5><i class="fa-solid fa-clipboard-question me-2"></i><?= htmlspecialchars($ficha['tema']) ?></h5>
                            <span class="badge bg-warning text-dark">Pendiente</span>
                        </div>

                        <?php if (!empty($ficha['realizada_por_o_encomendada_por'])): ?>
                            <p class="mb-1"><strong>Realizada por:</strong> <?= htmlspecialchars($ficha['realizada_por_o_encomendada_por']) ?></p>
                        <?php endif; ?>

                        <?php if (!empty($ficha['fecha_realizacion'])): ?>
                            <p class="mb-3"><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($ficha['fecha_realizacion'])) ?></p>
                        <?php endif; ?>

                        <button class="btn btn-primary mt-2" onclick="location.href='?f=<?= $ficha['id'] ?>'">
                            <i class="fas fa-play-circle me-2"></i>Comenzar Encuesta
                        </button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <!-- ENCUESTAS CONTESTADAS -->
            <?php if (count($encuestasContestadas) > 0): ?>
                <h4 class="text-start w-100 mb-3 mt-4" style="max-width: 800px;">
                    <i class="fas fa-check-circle text-success me-2"></i>Encuestas Contestadas
                </h4>
                <?php foreach ($encuestasContestadas as $ficha): ?>
                    <div class="card shadow-sm mb-4 p-4" style="max-width: 800px; width: 100%; opacity: 0.8; border-color: #0b1a89;">
                        <div class="d-flex justify-content-between align-items-start">
                            <h5><i class="fa-solid fa-clipboard-check me-2"></i><?= htmlspecialchars($ficha['tema']) ?></h5>
                            <span class="badge bg-success">Completada</span>
                        </div>

                        <?php if (!empty($ficha['realizada_por_o_encomendada_por'])): ?>
                            <p class="mb-1"><strong>Realizada por:</strong> <?= htmlspecialchars($ficha['realizada_por_o_encomendada_por']) ?></p>
                        <?php endif; ?>

                        <?php if (!empty($ficha['fecha_realizacion'])): ?>
                            <p class="mb-3"><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($ficha['fecha_realizacion'])) ?></p>
                        <?php endif; ?>

                        <div class="d-flex gap-2 mt-2 justify-content-center">
                            <button class="btn btn-primary" disabled>
                                <i class="fas fa-lock me-2"></i>Ya Contestada
                            </button>
                            <button class="btn btn-primary" onclick="verMisRespuestas(<?= $ficha['id'] ?>)">
                                <i class="fas fa-eye me-2"></i>Ver respuestas
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>

            <?php if (count($todasFichasTecnicas) === 0): ?>
                <div class="alert alert-warning text-center">No hay encuestas disponibles.</div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="card mb-4 p-4 shadow-sm mx-auto" style="max-width: 800px; border-color: #13357b;" >
            <h5><i class="fas fa-info-circle me-2"></i>Información de la Encuesta</h5>
            <?php if (!empty($fichaTecnica['tema'])): ?>
                <p><strong>Tema:</strong> <?= htmlspecialchars($fichaTecnica['tema']) ?></p>
            <?php endif; ?>
            <?php if (!empty($fichaTecnica['realizada_por_o_encomendada_por'])): ?>
                <p><strong>Realizada por:</strong> <?= htmlspecialchars($fichaTecnica['realizada_por_o_encomendada_por']) ?></p>
            <?php endif; ?>
            <?php if (!empty($fichaTecnica['fecha_realizacion'])): ?>
                <p><strong>Fecha:</strong> <?= date('d/m/Y', strtotime($fichaTecnica['fecha_realizacion'])) ?></p>
            <?php endif; ?>
        </div>

        <!-- BARRA PROGRESO -->
        <div class="progress mb-4 mx-auto" style="height: 10px; border-radius: 10px; max-width: 800px">
            <div class="progress-bar bg-primary" id="progress_bar" style="width: 0%;"></div>
        </div>

        <!-- Formulario de preguntas -->
        <form id="form_cuestionario">
            <input type="hidden" name="ficha_tecnica_id" value="<?= $fichaTecnicaId ?>">

            <?php if (count($preguntas) > 0): ?>
                <?php foreach ($preguntas as $index => $pregunta): ?>
                    <div class="card pregunta-card p-4 mb-4 shadow-sm mx-auto" 
                         style="max-width: 800px;" 
                         data-pregunta-id="<?= $pregunta['id'] ?>">

                        <h5 class="text-start"><?= ($index + 1) . '. ' . htmlspecialchars($pregunta['texto_pregunta']) ?></h5> 
                        
                        <div class="mt-3 text-start"> 
                            <?php
                            $tipoPregunta = $pregunta['tipo_pregunta'];
                            $inputType = $tipoPregunta === 'Seleccion_Multiple_multiple_respuesta' ? 'checkbox' : 'radio';

                            if (empty($pregunta['opciones']) || !is_array($pregunta['opciones'])) {
                                echo '<textarea class="form-control respuesta-texto" name="respuesta_texto_' . $pregunta['id'] . '" placeholder="Escribe tu respuesta..."></textarea>';
                            } else {
                                foreach ($pregunta['opciones'] as $opcion) {
                                    echo '
                                    <div class="text-start"> 
                                        <input class="form-check-input" type="' . $inputType . '" 
                                               name="respuesta_' . $pregunta['id'] . ($inputType === 'checkbox' ? '[]' : '') . '" 
                                               value="' . $opcion['id'] . '">
                                        <label class="form-check-label">' . htmlspecialchars($opcion['texto']) . '</label>
                                    </div>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="text-center mt-5">
                    <button type="submit" class="btn px-3 py-2" style="background-color: #0b1a89; color: #fff;">
                        <i class="fas fa-paper-plane me-2"></i>Enviar Respuestas
                    </button>
                </div>
            <?php else: ?>
                <div class="alert alert-info text-center">No hay preguntas registradas para esta encuesta.</div>
            <?php endif; ?>
        </form>
    <?php endif; ?>
</div>

<!-- Modal para Ver Respuestas -->
<div class="modal fade" id="modalVerRespuestas" tabindex="-1" aria-labelledby="modalVerRespuestasLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #13357b;">
                <h5 class="modal-title" id="modalVerRespuestasLabel" style="color: #fff;">
                    <i class="fas fa-clipboard-check me-2"></i>Respuestas
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="contenedor-respuestas">
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                        <p class="mt-2">Cargando tus respuestas...</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<?php include './admin/include/perfil.php'; ?>
<?php include './admin/include/footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="admin/js/perfil.js"></script>

<?php if (!$mostrarSelector): ?>
    <script src="admin/js/lib/util.js"></script>
    <script src="admin/js/contestar_cuestionario.js"></script>
<?php else: ?>
    <script src="admin/js/lib/util.js"></script>
    <script>
        function verMisRespuestas(fichaTecnicaId) {
            // Abrir modal
            const modal = new bootstrap.Modal(document.getElementById('modalVerRespuestas'));
            modal.show();

            // Mostrar spinner
            $('#contenedor-respuestas').html(`
                <div class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Cargando...</span>
                    </div>
                    <p class="mt-2">Cargando tus respuestas...</p>
                </div>
            `);

            // Hacer petición AJAX
            $.ajax({
                url: 'admin/ajax/rqst.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    op: 'respuestavotante',
                    ficha_tecnica_id: fichaTecnicaId
                },
                success: function(response) {
                    console.log('Respuesta:', response);

                    if (response.output && response.output.valid) {
                        const data = response.output.response;
                        const fechaRespuesta = data.fecha_respuesta;
                        const respuestas = data.respuestas;

                        let html = `
                            <div class="alert alert-info">
                                <i class="fas fa-calendar-alt me-2"></i>
                                <strong>Fecha de respuesta:</strong> ${formatearFecha(fechaRespuesta)}
                            </div>
                        `;

                        if (respuestas.length === 0) {
                            html += '<div class="alert alert-warning">No se encontraron respuestas.</div>';
                        } else {
                            respuestas.forEach((respuesta, index) => {
                                html += `
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h6 class="card-subtitle mb-3 text-muted">Pregunta ${index + 1}</h6>
                                            <p class="fw-bold">${respuesta.texto_pregunta}</p>
                                `;

                                // Mostrar opciones seleccionadas
                                if (respuesta.opciones_seleccionadas && respuesta.opciones_seleccionadas.length > 0) {
                                    html += '<div class="mt-2">';
                                    html += '<p class="mb-1"><strong>Respuesta:</strong></p>';
                                    html += '<ul class="list-unstyled ms-3">';
                                    respuesta.opciones_seleccionadas.forEach(opcion => {
                                        html += `<li><i class="fas fa-check-circle text-success me-2"></i>${opcion}</li>`;
                                    });
                                    html += '</ul>';
                                    html += '</div>';
                                }

                                // Mostrar respuesta de texto
                                if (respuesta.respuesta_texto) {
                                    html += `
                                        <div class="mt-2">
                                            <p class="mb-1"><strong>Respuesta:</strong></p>
                                            <div class="alert alert-light mb-0">${respuesta.respuesta_texto}</div>
                                        </div>
                                    `;
                                }

                                html += `
                                        </div>
                                    </div>
                                `;
                            });
                        }

                        $('#contenedor-respuestas').html(html);
                    } else {
                        $('#contenedor-respuestas').html(`
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Error al cargar las respuestas.
                            </div>
                        `);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    $('#contenedor-respuestas').html(`
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Error de conexión. Por favor, intenta nuevamente.
                        </div>
                    `);
                }
            });
        }

        function formatearFecha(fechaStr) {
            const fecha = new Date(fechaStr);
            const opciones = {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            };
            return fecha.toLocaleDateString('es-ES', opciones);
        }
    </script>
<?php endif; ?>
</body>
</html>
