<?php
require_once './admin/include/generic_classes.php';
include './admin/db/colores.php';
include './admin/classes/Main.php';
include './admin/classes/MapaConfig.php';

// Obtener código de municipio desde la sesión
$codigoMunicipioSessionVotante = SessionData::getCodigoMunicipioSessionVotante();
try {
  $codigoDepartamento = isset($_REQUEST['dep']) ? $_REQUEST['dep'] : Util::getDepartamentoPrincipal();
  $mapaMostrar = MapaConfig::obtenerRutaMapa($codigoDepartamento);
} catch (InvalidArgumentException $e) {
  echo "<script>
      alert('Información enviada no es correcta');
      window.location = 'dashboard.php';
  </script>";
  exit;
}

// Información del main
$arr = Main::getDataMain(['codigoDepartamento' => $codigoDepartamento]);
$isvalid = $arr['output']['valid'];
$visitas = $arr['output']['visitas'];
$lideres = $arr['output']['lideres'];
$municipios = $arr['output']['municipios'];
$inscritos = $arr['output']['inscritos'];
$reuniones = $arr['output']['reuniones'];
$departamentoInfo = $arr['output']['departamento'];

// Información del proyecto
$config = Util::getInformacionConfiguracion();
$nombreProyecto = $config[0]['nombre_proyecto'] ?? '';
$logo = $config[0]['logo'] ?? '';

$nombreUsuario = $_SESSION['session_user']['nombre_completo'] ?? $_SESSION['session_user']['usuario'] ?? 'Usuario';
$partes = explode(' ', $nombreUsuario);
$primerNombre = $partes[0] ?? 'Usuario';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Dashboard Colombia - <?php echo htmlspecialchars($departamentoInfo); ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600&family=Roboto&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
 
</head>
<body>
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <?php include './admin/include/menusecond.php'; ?>  

    <div class="container-fluid py-4">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">

                    <div class="d-flex justify-content-between align-items-center mb-4">

                        <button onclick="goBack()" 
                                class="btn btn-outline-primary btn-sm d-flex align-items-center"
                                style="box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                            <i class="fas fa-arrow-left me-2"></i>
                            <span>Volver</span>
                        </button>

                        <h4 class="fw-bold text-primary mb-0 flex-grow-1 text-center">
                            <i class="fas fa-map me-2"></i>
                            Mapa del Departamento de <?php echo htmlspecialchars($departamentoInfo); ?>
                        </h4>

                        <div style="width: 100px;"></div>
                    </div>

                    <div class="card shadow-lg border-0 rounded-4 p-4">
                        <div class="row g-4 align-items-start">

                            <div class="col-lg-8 col-md-7">
                                <div class="p-3 border rounded-3 bg-white shadow-sm">
                                    <?php require_once $mapaMostrar; ?>
                                </div>
                            </div>

                            <!-- DERECHA con la misma distribución exacta del ejemplo -->
                            <div class="col-lg-4 col-md-5">

                                <div class="text-center px-3 mb-4">

                                    <h3 class="fw-bold mb-2 text-primary">
                                        <i class="fas fa-user-check me-2"></i>
                                        Hola <?php echo htmlspecialchars($primerNombre); ?>
                                    </h3>

                                    <p class="text-muted fs-5 mb-3">
                                        Estás registrado para votar en el municipio de 
                                        <b><?php echo htmlspecialchars($_SESSION['session_user']['municipio_nombre']); ?></b>.
                                    </p>

                                    <div class="d-flex justify-content-center mb-2">
                                        <i class="fas fa-location-dot fa-3x text-primary"></i>
                                    </div>

                                </div>

                               <div class="p-3 border rounded-3 bg-light shadow-sm">

                                    <h5 class="fw-bold mb-3 text-center">
                                        <i class="fas fa-chart-pie me-2 text-primary"></i>
                                        % de votantes estimado
                                    </h5>

                                    <div style="height:150px;">
                                        <canvas id="graficoVotantes"></canvas>
                                    </div>

                                    <p class="text-muted mt-3 text-center" style="font-size:14px;">
                                        Datos aproximados basados en elecciones previas.
                                    </p>


                                </div>


                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>



    <?php include './admin/include/perfil.php';?>
    <?php include './admin/include/footer.php';?>

    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script src="js/main.js"></script>
    <script src="admin/js/perfil.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function goBack() {

    if (window.history.length > 1) {
        window.history.back();
    } else {
        window.location.href = "dashboard.php";
    }
}
</script>

    <script>
    window.MAPA_COLOR_NEUTRO = "<?= Util::getColorNeutroMapa(); ?>";
    </script>
    <script src="admin/js/Dashboard_colombia.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById("graficoVotantes");

    new Chart(ctx, {
        type: "doughnut",
        data: {
            labels: ["Votantes", "No votantes"],
            datasets: [{
                data: [58, 42],
                backgroundColor: ["#13357b", "#cbd5e1"],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: "bottom" }
            }
        }
    });
});

</script>
</body>
</html>