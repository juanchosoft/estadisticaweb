<?php
require './admin/include/generic_classes.php';
include './admin/include/generic_info_configuracion.php';
require './admin/classes/PreguntaGrilla.php';
require './admin/classes/Votantes.php';

if (isset($_POST['registro_data']) && !empty($_POST['registro_data'])) {
    $itemJson = $_POST['registro_data'];
    $grilla = json_decode($itemJson, true);
    if ($grilla === null && json_last_error() !== JSON_ERROR_NONE) {
        die("Error al decodificar los datos JSON: " . json_last_error_msg());
    }
} else {
    echo "Error: Acceso inválido o no se recibieron datos del registro.";
    exit;
}

// Cargar preguntas y subpreguntas desde la base de datos FILTRADAS por grilla_id
$grilla_id = isset($grilla['id']) ? $grilla['id'] : 0;
$preguntasResponse = PreguntaGrilla::obtenerPreguntasConSubpreguntas(['grilla_id' => $grilla_id]);
$preguntasData = [];
$subpreguntasData = [];

if ($preguntasResponse['output']['valid']) {
    $preguntasData = $preguntasResponse['output']['response']['preguntas'];
    $subpreguntasData = $preguntasResponse['output']['response']['subpreguntas'];
}

// Si no hay preguntas configuradas, mostrar error
if (empty($preguntasData)) {
    die("Error: No se encontraron preguntas configuradas en el sistema. Por favor, configure las preguntas desde el panel de administración.");
}

// Cargar votantes activos que NO han votado hoy en esta grilla
$votantesData = [];
$db = new DbConection();
$pdo = $db->openConect();

try {
    $qVotantes = "SELECT v.*
                  FROM " . $db->getTable('tbl_votantes') . " v
                  WHERE v.estado = 'activo'
                    AND v.id NOT IN (
                        SELECT gsv.tbl_votante_id
                        FROM " . $db->getTable('tbl_grilla_sesion_votacion') . " gsv
                        WHERE gsv.tbl_grilla_id = :grilla_id
                          AND DATE(gsv.dtcreate) = CURDATE()
                    )
                  ORDER BY v.nombre_completo ASC";

    $stmt = $pdo->prepare($qVotantes);
    $stmt->execute([':grilla_id' => $grilla_id]);
    $votantesData = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $votantesData = [];
} finally {
    $db->closeConect();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Elecciones Colombia - Preguntas</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500;600&family=Roboto&display=swap" rel="stylesheet">

    <!-- Iconos -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Librerías -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Estilo principal -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Select2 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@1.5.2/dist/select2-bootstrap4.min.css" rel="stylesheet" />
</head>
<body>

<div class="container-fluid p-0">
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top shadow px-4 px-lg-5 py-3 py-lg-0">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
            <!-- Menú para escritorio -->
            <div class="navbar-nav ms-auto d-none d-lg-flex">
                <!-- Dropdown Pendientes por responder -->
                <a href="dash_responder.php" class="nav-item nav-link">pendiente por responder</a>
                <a href="visualizar.php" class="nav-item nav-link">Visualización</a>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-2 text-primary fa-2x"></i>
                        <span class="welcome-text">
                            <?php
                            // Mostrar solo los dos primeros nombres
                            $nombreCompleto = $_SESSION['session_user']['nombre_completo'] ?? $_SESSION['session_user']['usuario'] ?? 'Usuario';
                            $partes = explode(' ', $nombreCompleto);
                            $dosNombres = implode(' ', array_slice($partes, 0, 2));
                            echo htmlspecialchars($dosNombres);
                            ?>
                        </span>
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="#" onclick="PERFIL.loadProfile(<?php echo $_SESSION['session_user']['id']; ?>); return false;">
                                <i class="fas fa-user me-2"></i>Mi Perfil
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Menú para móvil -->
            <div class="navbar-nav ms-auto d-lg-none w-100">
                <div class="user-info-mobile mb-3 p-3">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-user-circle me-3 text-primary fa-2x"></i>
                        <div>
                            <span class="welcome-text fw-bold d-block">
                                <?php
                                $nombreCompleto = $_SESSION['session_user']['nombre_completo'] ?? $_SESSION['session_user']['usuario'] ?? 'Usuario';
                                $partes = explode(' ', $nombreCompleto);
                                $dosNombres = implode(' ', array_slice($partes, 0, 2));
                                echo htmlspecialchars($dosNombres);
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="nav-item dropdown mb-2">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-tasks me-3"></i>
                        <span>Pendientes por responder</span>
                    </a>
                    <ul class="dropdown-menu w-100">
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="sondeo.php">
                                <i class="fas fa-poll me-2"></i>
                                <span>Sondeo</span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="grilla.php">
                                <i class="fas fa-chart-bar me-2"></i>
                                <span>Estudio</span>
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="encuesta.php">
                                <i class="fas fa-clipboard-list me-2"></i>
                                <span>Encuesta</span>
                            </a>
                        </li>
                    </ul>
                </div>
                
                <a href="visualizar.php" class="nav-item nav-link mb-2 d-flex align-items-center">
                    <i class="fas fa-chart-bar me-3"></i>
                    <span>Visualización</span>
                </a>
                
                <div class="dropdown-divider my-3"></div>
                
                <a href="#" class="nav-item nav-link mb-2 d-flex align-items-center" onclick="PERFIL.loadProfile(<?php echo $_SESSION['session_user']['id']; ?>); return false;">
                    <i class="fas fa-user me-3"></i>
                    <span>Mi Perfil</span>
                </a>
                <a href="logout.php" class="nav-item nav-link text-danger mb-2 d-flex align-items-center">
                    <i class="fas fa-sign-out-alt me-3"></i>
                    <span>Cerrar Sesión</span>
                </a>
            </div>
        </div>
    </nav>
</div>

<!-- <div id="contenedor-reloj" class="reloj-container">
    <span id="reloj-colombia"></span>
</div> -->

<div class="container-fluid grilla-section py-5">
    <div class="container">
        <div class="mx-a
        uto text-center mb-5">
            <h5 class="section-title px-3"><?= htmlspecialchars($grilla['grilla']); ?></h5>
            <h1 class="mb-0">Candidatos</h1>
        </div>

        <div class="row">

            <div class="col-lg-8 col-md-12">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-0">
                        <table class="tabla_grilla">
                            <thead class="table-header">
                                <tr>
                                    <th>CANDIDATOS</th>
                                    <?php
                                    // Renderizar headers dinámicamente desde la BD
                                    foreach ($preguntasData as $pregunta) {
                                        echo '<th>' . htmlspecialchars(strtoupper($pregunta['texto_pregunta'])) . '</th>';
                                    }
                                    ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (isset($grilla['candidatos']) && is_array($grilla['candidatos'])) {
                                    foreach ($grilla['candidatos'] as $index => $candidato) {
                                        $candidatoId = $candidato['id'];
                                        $nombreCompleto = htmlspecialchars($candidato['nombre_completo']);
                                        $fotoUrl = !empty($candidato['foto'])
                                            ? 'assets/img/admin/' . htmlspecialchars($candidato['foto'])
                                            : 'assets/img/candidato.png';
                                        $partidosPoliticos = htmlspecialchars($candidato['nombres_partidos'] ?? '');
                                        $cargoPublico = htmlspecialchars($candidato['cargo_publico'] ?? '');
                                ?>
                                <tr data-candidato-id="<?php echo $candidatoId; ?>">
                                    <!-- Columna del candidato -->
                                    <td class="candidato-info">
                                        <div class="candidato-container">
                                            <img src="<?php echo $fotoUrl; ?>" alt="Foto <?php echo $nombreCompleto; ?>" class="candidato-foto">
                                            <div class="candidato-detalles">
                                                <strong><?php echo $nombreCompleto; ?></strong>
                                            </div>
                                        </div>
                                    </td>

                                    <?php
                                    // Renderizar columnas de preguntas dinámicamente
                                    foreach ($preguntasData as $indexPregunta => $pregunta) {
                                        $codigoPregunta = $pregunta['codigo_pregunta'];
                                        $opcionesRespuesta = json_decode($pregunta['opciones_respuesta'], true);
                                        $esPrimera = ($indexPregunta === 0);

                                        // Determinar si es la primera pregunta (activa por defecto) o siguiente (NO APLICA por defecto)
                                        $claseInicial = $esPrimera ? '' : 'no-aplica';
                                        $toggleDisplay = $esPrimera ? 'flex' : 'none';
                                        $mostrarNoAplica = !$esPrimera;
                                    ?>
                                    <td data-pregunta="<?php echo $codigoPregunta; ?>"
                                        data-orden="<?php echo $pregunta['orden']; ?>"
                                        data-habilita-subpreguntas="<?php echo $pregunta['habilita_subpreguntas'] ? '1' : '0'; ?>"
                                        data-condicion="<?php echo htmlspecialchars($pregunta['condicion_habilitacion'] ?? ''); ?>"
                                        class="<?php echo $claseInicial; ?>">
                                        <div class="toggle" style="display: <?php echo $toggleDisplay; ?>;">
                                            <?php
                                            // Renderizar botones según las opciones configuradas
                                            if ($opcionesRespuesta && is_array($opcionesRespuesta)) {
                                                foreach ($opcionesRespuesta as $indexOpcion => $opcion) {
                                                    $esSegundaOpcion = ($indexOpcion === 1);
                                                    $claseActiva = ($esPrimera && $esSegundaOpcion) ? 'active' : ''; // Segunda opción activa en primera pregunta
                                                    $icono = '';

                                                    // Determinar icono según la opción
                                                    if ($opcion === 'si') {
                                                        $icono = '<i class="fas fa-check"></i>';
                                                        $claseBoton = 'si';
                                                    } elseif ($opcion === 'no') {
                                                        $icono = '<i class="fas fa-times"></i>';
                                                        $claseBoton = 'no';
                                                    } elseif ($opcion === 'favorable') {
                                                        $texto = 'SÍ';
                                                        $claseBoton = 'si';
                                                    } elseif ($opcion === 'desfavorable') {
                                                        $texto = 'NO';
                                                        $claseBoton = 'no';
                                                    } else {
                                                        $texto = strtoupper($opcion);
                                                        $claseBoton = $indexOpcion === 0 ? 'si' : 'no';
                                                    }
                                            ?>
                                            <button class="toggle-btn <?php echo $claseBoton; ?> <?php echo $claseActiva; ?>"
                                                    data-value="<?php echo $opcion; ?>">
                                                <?php echo !empty($icono) ? $icono : $texto; ?>
                                            </button>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </div>
                                        <?php if ($mostrarNoAplica): ?>
                                        <span class="no-aplica-text">--</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php
                                    } // fin foreach preguntas
                                    ?>
                                </tr>
                                <?php
                                    }
                                } else {
                                    $totalColumnas = count($preguntasData) + 1; // +1 para la columna de candidatos
                                    echo '<tr><td colspan="' . $totalColumnas . '" class="text-center">No hay candidatos disponibles</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>

                       <div class="mt-4 text-right">
                            <button type="button" class="btn btn-secondary" onclick="window.location.href='grilla.php';">
                                <i class="fas fa-arrow-left"></i> Volver
                            </button>
                            <button type="button" class="btn btn-primary" id="btnGuardarRespuestas">
                                <i class="fas fa-save"></i> Guardar Respuestas
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Columna aprobados -->
            <div class="col-lg-4 col-md-12">
                <div class="card card-candidatos-aprobados h-100">
                    <div class="card-header text-white py-2" style="background: #13357b;">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                            <h6 class="mb-0 text-white">
                                <i class="fas fa-trophy" style="color: #a38630;"></i> CANDIDATOS APROBADOS
                            </h6>
                            <small style="font-size: 10px;">Pasaron todas las preguntas</small>
                            </div>
                            <div class="badge badge-light badge-pill" style="font-size: 16px; padding: 8px 12px;">
                            <strong id="totalAprobados">0</strong>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-2" id="candidatosAprobadosContainer" style="max-height: calc(100vh - 250px); overflow-y: auto;">
                        <div class="text-center text-muted py-4" id="mensajeVacio">
                            <i class="fas fa-info-circle fa-2x mb-2"></i>
                            <p class="mb-0" style="font-size: 12px;">Selecciona las respuestas para ver los candidatos aprobados</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include './admin/include/perfil.php';?>
<?php include './admin/include/footer.php'; ?>
<!-- En lugar de los 3 archivos PCoded -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Y luego tu script personalizado -->
  <script src="admin/js/lib/util.js"></script>
  <script src="admin/js/votaciones_grilla.js"></script>
  <script>
    // Inicializar el sistema cuando el DOM esté listo
    $(document).ready(function() {
      // Pasar los datos de la grilla desde PHP a JavaScript
      const grillaData = <?php echo json_encode($grilla ?? []); ?>;

      // Pasar configuración de preguntas y subpreguntas desde PHP
      const preguntasConfig = <?php echo json_encode($preguntasData ?? []); ?>;
      const subpreguntasConfig = <?php echo json_encode($subpreguntasData ?? []); ?>;

      // Inicializar el sistema de votaciones con configuración dinámica
      EstudioVotaciones.init(grillaData, preguntasConfig, subpreguntasConfig);
    });
  </script>

</body>
</html>
