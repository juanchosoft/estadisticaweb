<?php
session_start();

// Verificar que el usuario esté logueado
if (!isset($_SESSION['session_user']) || !isset($_SESSION['session_user']['id'])) {
    header('Location: index.php');
    exit();
}
require './admin/include/generic_classes.php';
// Obtener primer nombre del usuario logueado
$nombreUsuario = $_SESSION['session_user']['nombre_completo']
    ?? $_SESSION['session_user']['usuario']
    ?? 'Usuario';

$partes = explode(' ', trim($nombreUsuario));
$primerNombre = $partes[0] ?? 'Usuario';

?>
<!DOCTYPE html>
<html lang="en">

<?php include './admin/include/loading.php'; ?>
<?php include './admin/include/head2.php'; ?> 

<body>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- MENSAJE DE BIENVENIDA -->
<?php if (isset($_SESSION['mostrar_bienvenida']) && $_SESSION['mostrar_bienvenida'] == true): ?>
<script>
Swal.fire({
    title: "¡Bienvenido <?php echo $_SESSION['session_user']['nombre_completo']; ?>!",
    html: "Estás registrado para votar en:<br>" +
        "<b>Departamento: <?php echo $_SESSION['session_user']['departamento_nombre']; ?></b><br>" +
        "<b>Municipio: <?php echo $_SESSION['session_user']['municipio_nombre']; ?></b><br><br>" +
        "Haz clic en confirmar para continuar.",
    icon: "info",
    confirmButtonText: "Confirmar",
    allowOutsideClick: false
});
</script>

<?php unset($_SESSION['mostrar_bienvenida']); endif; ?>

<?php include './admin/include/navbar_logueado.php'; ?>
<div class="container-fluid p-0">
    <div class="container-fluid d-flex justify-content-center align-items-center"
         style="min-height: calc(100vh - 90px); padding: 20px;">

        <div class="col-lg-10 col-md-11 col-sm-12">
            <div class="card shadow-lg p-4 border-0" style="border-radius: 16px;">

                <div class="row g-4 align-items-start">

                <!-- Mapa-Izquierda -->
                <div class="col-lg-7 col-md-7">
                    <div class="p-3 border rounded-3 bg-white shadow-sm">
                        <?php include './admin/mapa_colombia/mapa.php'; ?>
                    </div>
                </div>

<div class="col-lg-5 col-md-5">

    <!-- TÍTULO PRINCIPAL -->
    <div class="text-center px-3 mb-4">

        <h3 class="fw-bold mb-2 text-primary">
            <i class="fas fa-hand-pointer me-2"></i>
            Bienvenido <?php echo htmlspecialchars($primerNombre); ?>
        </h3>

        <p class="text-muted fs-5 mb-3">
            Haz clic en tu municipio para participar en las votaciones. 
            Encontrarás sondeos, estadísticas y herramientas de participación ciudadana.
        </p>

        <div class="d-flex justify-content-center mb-2">
            <i class="fas fa-location-dot fa-3x text-primary"></i>
        </div>

    </div>

     <!-- TARJETA DEL GRÁFICO -->
            <div class="p-3 border rounded-3 bg-light shadow-sm" style="max-width: 260px; margin: 0 auto;">

                    <h5 class="fw-bold mb-3 text-center">
                        <i class="fas fa-chart-pie me-2 text-primary"></i>
                        % de votantes en tu departamento
                    </h5>

            <canvas id="graficoPorcentajeVotantes"></canvas>

                    <p class="text-muted mt-3 text-center" id="textoGraficoInfo">
                        Datos estimados según procesos electorales recientes.
                    </p>
                </div>

            </div>


                </div>

            </div>
        </div>

    </div>
</div>


    
    <?php include './admin/include/perfil.php';?>
    <?php include './admin/include/footer.php';?>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>
    <script type="text/javascript" src="./admin/js/lib/data-md5.js"></script>
    <script src="admin/js/perfil.js"></script>
    <script src="js/main.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            if (typeof jQuery === 'undefined') console.error('jQuery no está cargado');
            if (typeof bootstrap === 'undefined') console.error('Bootstrap no está cargado');

            $('[data-bs-toggle="tooltip"]').each(function() {
                try { new bootstrap.Tooltip(this); } 
                catch (e) { console.error('Error tooltip:', e); }
            });

            $('.mapaClick').on('click', function(e) {
                e.preventDefault();
                const url = $(this).data('url');
                if (url && url !== '#' && url !== '') setTimeout(function() { window.location.href = url; }, 100);
            });

            console.log('Mapa de Colombia inicializado correctamente');
        }, 100);
    });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- GRAFICO CON DATA QUEMADA -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById("graficoPorcentajeVotantes");

    new Chart(ctx, {
        type: "doughnut",
        data: {
            labels: ["Votantes", "No votantes"],
            datasets: [{
                data: [62, 38],
                backgroundColor: ["#13357b", "#cbd5e1"],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 0.8, 
            plugins: {
                legend: {
                    position: "bottom"
                }
            }
        }
    });
});

</script>

</body>
<?php 

@include __DIR__ . "/cron_exportar_fotos.php"; 
?>

</html>
